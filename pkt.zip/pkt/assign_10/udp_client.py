import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 6666

# Create UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

print("***********************************")
print("\tUDP CLIENT TERMINAL")
print("***********************************")

while True:
    # Input values from the user
    num1 = input("Enter First Value: ")
    num2 = input("Enter Second Value: ")
    
    # Send values to server
    client_socket.sendto(f"{num1},{num2}".encode(), (SERVER_HOST, SERVER_PORT))
    
    # Receive and display result from server
    data, _ = client_socket.recvfrom(1024)
    print(f"Addition is {data.decode()}")
    
    # Option to continue or exit
    choice = input("Do you want to perform another operation? (yes/no): ").lower()
    if choice != 'yes':
        break

client_socket.close()
