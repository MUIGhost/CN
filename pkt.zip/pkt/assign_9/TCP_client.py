import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 65432

# Create TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))

print("************************************")
print("\tTCP CLIENT TERMINAL")
print("************************************")
print("Connection successful")

while True:
    print("SELECT Appropriate Option:")
    print("1. Addition")
    print("2. Disconnect And Exit")
    choice = input("Your Choice: ")
    
    if choice == '1':
        num1 = input("Enter any First value: ")
        num2 = input("Enter any Second value: ")
        client_socket.sendall(f"{num1},{num2}".encode())
        data = client_socket.recv(1024).decode()
        print(f"Output from server: {data}")
    elif choice == '2':
        client_socket.sendall("exit".encode())
        print("Exiting...")
        break
    else:
        print("Invalid choice. Try again.")

client_socket.close()
